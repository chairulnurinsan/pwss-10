<form action="barang_tampil.php" method="post">
    <h2>.:: CARI BARANG ::.</h2>
    Nama Barang <input type="text" name="nama_barang" />
    <input type="submit" value="CARI" />
</form>